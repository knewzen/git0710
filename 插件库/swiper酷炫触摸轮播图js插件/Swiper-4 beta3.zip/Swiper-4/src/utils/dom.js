import $ from 'dom7/src/$';
import Methods from 'dom7/src/methods';

// Methods
$.use(Methods);

export default $;
