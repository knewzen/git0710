import setBreakpoint from './setBreakpoint';

export default { setBreakpoint };
