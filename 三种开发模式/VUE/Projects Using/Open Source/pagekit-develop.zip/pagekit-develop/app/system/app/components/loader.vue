<template>

    <svg class="pk-loader" width="30" height="30" viewBox="0 0 30 30" xmlns="http://www.w3.org/2000/svg">
        <g><circle cx="0" cy="0" r="13" fill="none" stroke-width="1"/></g>
    </svg>

</template>

<script>

    module.exports = {
        name: 'loader'
    };

</script>
