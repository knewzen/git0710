<?php

namespace Pagekit\Database\ORM\Annotation;

/**
 * The Annotation interface.
 */
interface Annotation
{
}
