<?php

namespace Pagekit\Application;

class Exception extends \RuntimeException
{
}
