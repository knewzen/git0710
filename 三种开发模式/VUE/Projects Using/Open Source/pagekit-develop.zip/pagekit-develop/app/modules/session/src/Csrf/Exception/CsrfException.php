<?php

namespace Pagekit\Session\Csrf\Exception;

use Pagekit\Kernel\Exception\UnauthorizedException;

class CsrfException extends UnauthorizedException
{
}