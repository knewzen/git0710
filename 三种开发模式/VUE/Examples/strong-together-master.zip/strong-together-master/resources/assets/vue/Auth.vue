<template>
    <div class="pusher">
      <header-component></header-component>
      <div class="ui page grid basic segment">
  			<router-view></router-view>
      </div>
      <footer-component></footer-component>
    </div>
</template>
