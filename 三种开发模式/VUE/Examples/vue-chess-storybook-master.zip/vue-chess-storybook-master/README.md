# Storybook VueChess Demo

Rewriting components in vue2.

Example
------

![example](images/chessStorybook.png "example")

 1. `git clone ...`
 2. `yarn install` 
 3. Run the dev storybook server (`yarn storybook`)


