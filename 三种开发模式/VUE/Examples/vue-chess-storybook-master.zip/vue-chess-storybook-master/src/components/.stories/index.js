import Vuex from 'vuex';
import { storiesOf } from '@storybook/vue';

require('./hello.js');
require('../boardHistory/storie.js');
require('../boardTimer/storie.js');
require('../chessboard/storie.js');
require('../puzzle/storie.js');
require('../scrollStaticDirection/storie.js');

