ngexplorer-vuejs-client
-----------------------



Implementación de cliente ligero para [NgExplorer](http://ngexplorer-beta.prod.uci.cu/#/) con Vuejs.
              
        npm install webpack -g
        npm install
        npm run dev

        http://localhost:8080

> Ver [DEMO](http://ngexplorer-beta.prod.uci.cu/vue#!/filter)


> Articulo [Cliente Vuejs para Ngexplorer](https://rice.uci.cu/?p=4523).
