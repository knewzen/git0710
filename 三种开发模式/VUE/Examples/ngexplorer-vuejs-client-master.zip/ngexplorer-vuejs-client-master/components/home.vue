<template>
<div class="col-xs-12 col-sm-12">
    

    <div class="jumbotron">
        <div class="row">
            <div class="col-sm-6 col-md-3">
                <a href="#" class="thumbnail">
                    <img src="http://ngexplorer-beta.prod.uci.cu/ngexplorer.png">
                </a>
            </div>
            <div class="col-sm-6 col-md-9">
                <div class="container">
                    <h1>ngExplorer</h1>
                    <p>Buscar información en los recursos compartidos de la Universidad (nuestros FTPs) nunca ha sido tan fácil, navega por los proveedores registrados y unifica la búsqueda entre ellos. </p>
                    <p><a class="btn btn-primary btn-lg" href="https://rice.uci.cu/?p=4523">Ver</a></p>
                </div>
            </div>
        </div>
    </div>
    <div id="footer">
        <div class="container" style="text-align: center;">
            <div class="copyrights">
                <div class="row" id="copyright-note">
                 <p class="text-muted credit">© 2016 <a href="https://codecomunidades.prod.uci.cu/u/gcrespo">Gustavo Crespo Sanchez</a> gcrespo@uci.cu</p>
             </div>
         </div>        
     </div>
 </div>

 </div>
</template>

<script>
	/**
	 * @example navbar demos
	 * @for navbar
	 * @description
	 */
	 module.exports = {
        
    };
</script>
