# vue-music-qq

> A Vue.js project for music
### Use
* vuejs-2.1.7
* vue-cli
* vue-router
* vuex
* muse-ui


## Support
* Chrome
* Firefox
* Mobile browser

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```
## Demo site(aliyun)

http://47.94.146.181/vue-music-qq

# Conatct

- Tencent QQ: 342878509
- E-mail: xiongmao1114@163.com
- Github: https://github.com/pluto1114/vue-music-qq
