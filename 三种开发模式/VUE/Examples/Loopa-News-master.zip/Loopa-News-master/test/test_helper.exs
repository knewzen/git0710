ExUnit.start

Ecto.Adapters.SQL.Sandbox.mode(Microscope.Repo, :manual)

