defmodule Microscope.LayoutView do
  use Microscope.Web, :view
end
