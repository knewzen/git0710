defmodule Microscope.PageView do
  use Microscope.Web, :view
end
