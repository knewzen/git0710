<p align="center"><a href="https://bosnaufal.github.io/vue-mini-shop"><img src="./assets/img/logo.png" width="175px" alt="Vue Mini Shop"/></a></p>

# Vue Mini Shop
Mini Online Shop Built With Vue JS and some of my plugins. It has enough features for starting build an Online Shop with Vue JS! You can use it, but don't forget to give me a credit link~

## [LIVE](https://bosnaufal.github.io/vue-mini-shop)

## Now You can work with it
```bash
npm install
npm run dev
#or
gulp
```

## Thank You for Making this become useful~
Hopefully it can be useful for your next projects.

## Need More?
Just Contact Me At:
- Email: [bosnaufalemail@gmail.com](mailto:bosnaufalemail@gmail.com)
- Skype Id: bosnaufal254
- twitter: [@BosNaufal](https://twitter.com/BosNaufal)

## License
[MIT](http://opensource.org/licenses/MIT)
Copyright (c) 2016 - forever Naufal Rabbani
