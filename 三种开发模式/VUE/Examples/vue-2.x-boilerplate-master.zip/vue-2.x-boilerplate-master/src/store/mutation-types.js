export const GET_FRIENDS = 'GET_FRIENDS'
export const ADD_FRIENDS = 'ADD_FRIENDS'
