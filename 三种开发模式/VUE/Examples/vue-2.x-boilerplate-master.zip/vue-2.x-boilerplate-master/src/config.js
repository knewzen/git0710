export default {
  name: 'vue 2.x boilerplate',
  version: '1.0'
}
