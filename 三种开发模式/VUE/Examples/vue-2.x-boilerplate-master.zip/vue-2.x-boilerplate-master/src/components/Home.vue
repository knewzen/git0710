<template>
  <section class="hero">
    <div class="hero-body">
      <div class="container">
        <h1 class="title">Home</h1>
      </div>
    </div>
  </section>
</template>

<script>
export default {
  name: 'Home'
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
