# Vue SoundCloud

First, you need register or log in to your SoundCloud account. Then, you also need to register your SoundCloud application at here http://soundcloud.com/you/apps.

After registered, grab the Client ID. Edit `index.html` file, and put your Client ID to

    const SC_CLIENT_ID = 'YOUR_CLIENT_ID';

Open the `index.html`. Enjoy, learn and happy hacking!
