
<template>
  <footer class="Footer">
    <p class="text-center Footer-copyright">Copyright &copy; Naufal Rabbani</p>
  </footer>
</template>

<script>

  export default {
  };

</script>
