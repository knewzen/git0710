
<template>
  <div class="PostList-item PostList-item--loading">
    <div class="PostList-item_thumbnail">
      <img src="../../../assets/img/blank-thumbnail.png" alt="">
    </div>
    <div class="PostList-item_body">
      <div class="PostList-block_line_title"></div>
      <div class="PostList-block_line"></div>
      <div class="PostList-block_line"></div>
      <div class="PostList-block_line"></div>
    </div>
  </div>
</template>

<script>

  export default {
  };

</script>
