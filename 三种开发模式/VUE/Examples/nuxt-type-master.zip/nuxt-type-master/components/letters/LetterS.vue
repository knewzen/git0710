<template>
  <svg class="letter letter-s" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 341.7 490.6">
  <defs>
    <radialGradient id="Super_Soft_Black_Vignette" data-name="Super Soft Black Vignette" cx="190.33" cy="363.45" r="59.86" gradientUnits="userSpaceOnUse">
      <stop offset=".57" stop-color="#130c0e" stop-opacity="0"/>
      <stop offset=".8" stop-color="#130c0e" stop-opacity=".65"/>
      <stop offset=".82" stop-color="#130c0e" stop-opacity=".7"/>
      <stop offset="1" stop-color="#130c0e" stop-opacity=".95"/>
    </radialGradient>
    <radialGradient id="Super_Soft_Black_Vignette-2" cx="197.87" cy="390.64" r="59.39" gradientTransform="matrix(1.3 0 0 1 -81.5 -28.3)" xlink:href="#Super_Soft_Black_Vignette"/>
    <radialGradient id="Super_Soft_Black_Vignette-3" cx="232.99" cy="178.62" r="59.86" gradientTransform="rotate(-90 225.7 198.2)" xlink:href="#Super_Soft_Black_Vignette"/>
    <radialGradient id="Super_Soft_Black_Vignette-4" cx="203.01" cy="182.89" r="59.39" gradientTransform="matrix(0 -1.3 1.1 0 26.1 456.3)" xlink:href="#Super_Soft_Black_Vignette"/>
  </defs>
  <title>
    type-rufina
  </title>
  <g id="t" data-name="Layer 3">
    <path d="M243.6 111.7a168.4 168.4 0 0 0-56.3-9.6q-28.9 0-50.7 16.5t-21.8 48.9q0 31.4 26.9 48.1 14.7 9.1 24.1 13.2t27.4 10.6q18 6.6 24.6 9.4l19.5 8.6q12.9 5.8 19.3 10.4t15.5 12.7a64.8 64.8 0 0 1 13.7 16.2 94 94 0 0 1 11.2 45.1q0 43.1-35 70.4t-90.7 27.4q-42.6 0-79.6-14.2-18.2-6.6-29.9-18.2T50 380.3q0-24.8 36-34 5.6 30.4 21.3 49.2t32.7 24.8q17 6.1 41.6 6.1t46.4-16q21.8-16 21.8-52.5 0-27.9-25.3-45.6-20.3-13.7-49.9-25.8l-40-16.4a237.5 237.5 0 0 1-26.1-13.7q-16-9.4-23.6-18.5a83.3 83.3 0 0 1-19.8-54.7q0-47.6 34-72t93.8-24.3q36 0 83.6 8.1v74.5h-15.7z" fill="#fff"/>
  </g>
  <g id="Layer_1" data-name="Layer 1">
    <g id="lines">
      <g fill="none" stroke="#fff" stroke-miterlimit="10">
        <path d="M115.3 46.6v1.3"/>
        <path stroke-dasharray="2.49 2.49" d="M115.3 50.3v437.8"/>
        <path d="M115.3 489.3v1.3"/>
      </g>
      <g fill="none" stroke="#fff" stroke-miterlimit="10">
        <path d="M86.6 4.9v1.3"/>
        <path stroke-dasharray="2.51 2.51" d="M86.6 8.7v464.7"/>
        <path d="M86.6 474.7v1.2"/>
      </g>
      <g opacity="0.4">
        <path fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.5" d="M12.3 86.4h329.4"/>
        <path fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.5" d="M14.7 440.1H320"/>
        <path fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.5" d="M0 346.1h190.7"/>
        <path fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.5" d="M137 169.8h190.7"/>
      </g>
      <g opacity=".44" fill="none" stroke="#fff" stroke-miterlimit="10">
          <path d="M49.7 0v1.3"/>
          <path stroke-dasharray="2.5 2.5" d="M49.7 3.7v483.1"/>
          <path d="M49.7 488.1v1.2"/>
      </g>
      <g opacity=".13" fill="none" stroke="#fff" stroke-miterlimit="10">
        <g fill="none" stroke="#fff" stroke-miterlimit="10">
          <path d="M241.7 115.3v1.3"/>
          <path stroke-dasharray="2.51 2.51" d="M241.7 119.1v340.4"/>
          <path d="M241.7 460.7v1.3"/>
        </g>
      </g>
      <g opacity=".13" fill="none" stroke="#fff" stroke-miterlimit="10">
          <path d="M296.4 20v1.2"/>
          <path stroke-dasharray="2.49 2.49" d="M296.4 23.7v297.8"/>
          <path d="M296.4 322.7v1.3"/>
      </g>
      <g opacity=".44" fill="none" stroke="#fff" stroke-miterlimit="10">
          <path d="M276.7 61.3v1.3"/>
          <path stroke-dasharray="2.52 2.52" d="M276.7 65.1v371.1"/>
          <path d="M276.7 437.4v1.3"/>
          <path fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.5" d="M224.7 56.1l46 140.7"/>
          <path fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.5" d="M76.3 318.4l46 140.7"/>
      </g>
    </g>
    <g id="circles" stroke="#fff" opacity="0.17" stroke-miterlimit="10">
      <circle cx="190.3" cy="363.4" r="59.9" fill="url(#Super_Soft_Black_Vignette)"/>
      <ellipse cx="174.8" cy="366.4" rx="76.9" ry="60" fill="url(#Super_Soft_Black_Vignette-2)"/>
      <ellipse cx="213.6" cy="190.8" rx="62.4" ry="59.9" transform="rotate(-80.8 180.3 199.5)" fill="url(#Super_Soft_Black_Vignette-3)"/>
      <ellipse cx="228" cy="193.3" rx="65.6" ry="76.9" transform="rotate(-80.8 194.7 202.6)" fill="url(#Super_Soft_Black_Vignette-4)"/>
    </g>
  </g>
</svg>
</template>
