<template>
  <svg class="letter letter-t" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 409.5 515.9" aria-labelledby="title">
  <defs>
    <radialGradient id="Super_Soft_Black_Vignette" data-name="Super Soft Black Vignette" cx="139.02" cy="169.93" r="54" gradientUnits="userSpaceOnUse">
      <stop offset="0.57" stop-color="#130c0e" stop-opacity="0"/>
      <stop offset="0.8" stop-color="#130c0e" stop-opacity="0.65"/>
      <stop offset="0.82" stop-color="#130c0e" stop-opacity="0.7"/>
      <stop offset="1" stop-color="#130c0e" stop-opacity="0.95"/>
    </radialGradient>
    <radialGradient id="Super_Soft_Black_Vignette-2" cx="273.56" cy="170.46" r="54" xlink:href="#Super_Soft_Black_Vignette"/>
    <radialGradient id="Super_Soft_Black_Vignette-3" cx="155.02" cy="416.92" r="27" xlink:href="#Super_Soft_Black_Vignette"/>
    <radialGradient id="Super_Soft_Black_Vignette-4" cx="258.56" cy="417.93" r="27" xlink:href="#Super_Soft_Black_Vignette"/>
  </defs>
  <title id="title" lang="en">
    Representative T Typography for Playfair
  </title>
  <g>
    <g id="t">
      <path d="M77,174.3a612.1,612.1,0,0,0-3.7-64q41.5,1.5,141.1,1.5t140.4-1.5q-3.4,35.6-3.4,64,0,25.1,1.5,41H341.4q-3.9-38.8-9.9-57.5t-21-27.3q-15-8.7-46-8.7H237.4V406.2q0,20.8,3.9,30.4a22.8,22.8,0,0,0,14.2,13.3q10.3,3.7,32.5,4.4v10q-26.4-1.5-73.5-1.5-50.1,0-74,1.5v-10q22.2-.7,32.5-4.4a22.8,22.8,0,0,0,14.2-13.3q3.9-9.6,3.9-30.4V121.8H163.9q-31,0-46,8.7t-21,27.3q-6,18.7-9.9,57.5H75.5Q77,199.4,77,174.3Z" transform="translate(-8.1 -6.9)" fill="#fff"/>
    </g>
    <g id="circles" opacity="0.17">
      <circle cx="139" cy="169.9" r="54" stroke="#fff" stroke-miterlimit="10" fill="url(#Super_Soft_Black_Vignette)"/>
      <circle cx="273.6" cy="170.5" r="54" stroke="#fff" stroke-miterlimit="10" fill="url(#Super_Soft_Black_Vignette-2)"/>
      <circle cx="155" cy="416.9" r="27" stroke="#fff" stroke-miterlimit="10" fill="url(#Super_Soft_Black_Vignette-3)"/>
      <circle cx="258.6" cy="417.9" r="27" stroke="#fff" stroke-miterlimit="10" fill="url(#Super_Soft_Black_Vignette-4)"/>
    </g>
    <g id="lines">
      <g opacity="0.16">
        <g>
          <line x1="181.5" y1="71.9" x2="181.5" y2="73.2" fill="none" stroke="#fff" stroke-miterlimit="10"/>
          <line x1="181.5" y1="75.7" x2="181.5" y2="513.4" fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.49 2.49"/>
          <line x1="181.5" y1="514.7" x2="181.5" y2="515.9" fill="none" stroke="#fff" stroke-miterlimit="10"/>
        </g>
        <g>
          <line x1="229.5" y1="20.9" x2="229.5" y2="22.2" fill="none" stroke="#fff" stroke-miterlimit="10"/>
          <line x1="229.5" y1="24.7" x2="229.5" y2="489.4" fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.51 2.51"/>
          <line x1="229.5" y1="490.7" x2="229.5" y2="491.9" fill="none" stroke="#fff" stroke-miterlimit="10"/>
        </g>
        <g>
          <path d="M8.2,107.3H9.4" transform="translate(-8.1 -6.9)" fill="none" stroke="#fff" stroke-miterlimit="10"/>
          <path d="M11.9,107.5c31.1,1.4,250.3,10.9,403.2,0" transform="translate(-8.1 -6.9)" fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.5 2.5"/>
          <path d="M416.4,107.4h1.2" transform="translate(-8.1 -6.9)" fill="none" stroke="#fff" stroke-miterlimit="10"/>
        </g>
        <g>
          <path d="M96.7,466.8h1.2" transform="translate(-8.1 -6.9)" fill="none" stroke="#fff" stroke-miterlimit="10"/>
          <path d="M100.4,466.5c20.3-1.6,121.2-8.2,236.8,3.1" transform="translate(-8.1 -6.9)" fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.48 2.48"/>
          <path d="M338.4,469.7h1.2" transform="translate(-8.1 -6.9)" fill="none" stroke="#fff" stroke-miterlimit="10"/>
        </g>
      </g>
      <g opacity="0.44">
        <g>
          <line x1="64.6" y1="18" x2="64.6" y2="19.3" fill="none" stroke="#fff" stroke-miterlimit="10"/>
          <line x1="64.6" y1="21.7" x2="64.6" y2="504.8" fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.5 2.5"/>
          <line x1="64.6" y1="506.1" x2="64.6" y2="507.3" fill="none" stroke="#fff" stroke-miterlimit="10"/>
        </g>
      </g>
      <g opacity="0.13">
        <g>
          <line x1="78.6" y1="36.7" x2="78.6" y2="37.9" fill="none" stroke="#fff" stroke-miterlimit="10"/>
          <line x1="78.6" y1="40.4" x2="78.6" y2="380.8" fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.51 2.51"/>
          <line x1="78.6" y1="382.1" x2="78.6" y2="383.3" fill="none" stroke="#fff" stroke-miterlimit="10"/>
        </g>
      </g>
      <g opacity="0.13">
        <g>
          <line x1="333.2" y1="38" x2="333.2" y2="39.3" fill="none" stroke="#fff" stroke-miterlimit="10"/>
          <line x1="333.2" y1="41.7" x2="333.2" y2="339.5" fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.49 2.49"/>
          <line x1="333.2" y1="340.7" x2="333.2" y2="342" fill="none" stroke="#fff" stroke-miterlimit="10"/>
        </g>
      </g>
      <g opacity="0.44">
        <g>
          <line x1="346.9" x2="346.9" y2="1.3" fill="none" stroke="#fff" stroke-miterlimit="10"/>
          <line x1="346.9" y1="3.8" x2="346.9" y2="374.8" fill="none" stroke="#fff" stroke-miterlimit="10" stroke-dasharray="2.52 2.52"/>
          <line x1="346.9" y1="376.1" x2="346.9" y2="377.3" fill="none" stroke="#fff" stroke-miterlimit="10"/>
        </g>
      </g>
    </g>
  </g>
</svg>
</template>
