<template>
  <svg class="letter letter-t" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 409.54 496.58" aria-labelledby="title">
  <defs>
    <radialGradient id="a" data-name="Super Soft Black Vignette" cx="200.48" cy="200.35" r="79.57" gradientUnits="userSpaceOnUse">
      <stop offset=".57" stop-color="#130c0e" stop-opacity="0"/>
      <stop offset=".8" stop-color="#130c0e" stop-opacity=".65"/>
      <stop offset=".82" stop-color="#130c0e" stop-opacity=".7"/>
      <stop offset="1" stop-color="#130c0e" stop-opacity=".95"/>
    </radialGradient>
    <radialGradient id="b" cx="249.58" cy="199.38" r="84.85" gradientTransform="matrix(1.14 0 0 1.03 -48.16 -4.98)" xlink:href="#a"/>
    <radialGradient id="c" cx="200.53" cy="322.44" r="53.85" xlink:href="#a"/>
    <radialGradient id="d" cx="343.14" cy="403.39" r="18.34" xlink:href="#a"/>
  </defs>
  <title id="title" lang="en">
    Representative R Typography for Prata
  </title>
  <g id="r">
    <path d="M284.36 429.9q-12.34-11.88-16.74-40.5l-8.37-59q-4.4-29.95-20.48-46.92t-50-17h-34.34v155l40.52 6.63v9.26H65.45v-9.25l40.53-6.6V100.9l-40.52-6.16v-9.7h123.32q71.78 0 103.94 22.47t32.13 68.28q0 75.76-91.6 87.65v2.68q33.9 4.86 54.38 24.23t25.76 51.53l5.72 37.88q3.52 24.67 8.15 33.47t14.3 8.82q6.62 0 14.1-4.18a64.33 64.33 0 0 0 14.1-10.8l7.48 7.94q-12.78 14.53-26.43 20.7a70.9 70.9 0 0 1-29.5 6.17q-24.64-.05-36.96-11.94zm-80.6-174q32.14 0 50-19.6t17.84-57.9v-9.26q0-73.1-82.8-73.1h-34.37v159.9z" fill="#fff"/>
  </g>
  <g data-name="Layer 1">
    <g>
      <g id="circles" opacity=".17" stroke="#fff" stroke-miterlimit="10">
        <path d="M200.38 279.7c-45-2.62-79.43-35.57-79.43-79.44s35.6-81.53 79.43-79.43c62.13 3 78.8 36.1 79.57 71.48 1.38 62.7-22.62 90.7-79.57 87.4z" transform="translate(-8.15 -24.89)" fill="url(#a)"/>
        <path d="M334 201.66c0 48.2-39 87.2-98.23 86.33C168 287 141 249.85 141 201.65s29.65-90.58 93.65-89.33c68.02 1.34 99.35 41.14 99.35 89.33z" transform="translate(-8.15 -24.89)" opacity=".53" fill="url(#b)"/>
        <circle cx="200.53" cy="322.44" r="53.85" fill="url(#c)"/>
        <circle cx="343.14" cy="403.39" r="18.34" fill="url(#d)"/>
      </g>
      <g id="lines">
        <g opacity=".16" fill="none" stroke="#fff" stroke-miterlimit="10">
          <g>
            <path d="M155.5 52.6v1.25"/>
            <path stroke-dasharray="2.49 2.49" d="M155.5 56.35v437.73"/>
            <path d="M155.5 495.33v1.25"/>
          </g>
          <g>
            <path d="M106.17 1.6v1.25"/>
            <path stroke-dasharray="2.51 2.51" d="M106.17 5.36v464.72"/>
            <path d="M106.17 471.33v1.25"/>
          </g>
          <g>
            <path d="M0 85.77h1.26"/>
            <path d="M3.75 85.67c31-.8 248.58-5.82 403.24 6.9" stroke-dasharray="2.5 2.5"/>
            <path d="M408.24 92.66l1.25.1"/>
          </g>
          <g>
            <path d="M75.17 271.25l1.24-.1"/>
            <path d="M78.85 270.95c20.3-1.56 121.22-8.22 236.8 3.05" stroke-dasharray="2.48 2.48"/>
            <path d="M316.92 274.1l1.24.13"/>
          </g>
        </g>
        <g opacity=".44">
          <g fill="none" stroke="#fff" stroke-miterlimit="10">
            <path d="M64.56 0v1.25"/>
            <path stroke-dasharray="2.5 2.5" d="M64.56 3.75v483.1"/>
            <path d="M64.56 488.08v1.25"/>
          </g>
        </g>
        <g opacity=".13">
          <g fill="none" stroke="#fff" stroke-miterlimit="10">
            <path d="M270.56 115.33v1.25"/>
            <path stroke-dasharray="2.51 2.51" d="M270.56 119.1v340.4"/>
            <path d="M270.56 460.75V462"/>
          </g>
        </g>
        <g opacity=".13">
          <g fill="none" stroke="#fff" stroke-miterlimit="10">
            <path d="M325.22 20v1.25"/>
            <path stroke-dasharray="2.49 2.49" d="M325.22 23.74V321.5"/>
            <path d="M325.22 322.75V324"/>
          </g>
        </g>
        <g opacity=".44">
          <g fill="none" stroke="#fff" stroke-miterlimit="10">
            <path d="M376.22 67.33v1.25"/>
            <path stroke-dasharray="2.52 2.52" d="M376.22 71.1v371.06"/>
            <path d="M376.22 443.42v1.25"/>
          </g>
        </g>
      </g>
    </g>
  </g>
</svg>

</template>

<style>
</style>
