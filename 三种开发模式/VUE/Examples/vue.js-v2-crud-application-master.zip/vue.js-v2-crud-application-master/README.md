## Vue.js v2 CRUD sample application

Uses vue.js v2.0 and vue-router v2.0

 - Forked from [this demo](http://codepen.io/-a/pen/amOYGp) using vue.js 1.x
 - [Demo on codepen](http://codepen.io/shershen08/pen/xROOxw)

### Usage
 - clone or download zip of this repo
 - `cd` to the upacked folder
 - run `npm install`
 - run http server of your choice (eg [whs](https://github.com/gstack/watch-http-server) or [SimpleHTTPServer](https://docs.python.org/2/library/simplehttpserver.html))
