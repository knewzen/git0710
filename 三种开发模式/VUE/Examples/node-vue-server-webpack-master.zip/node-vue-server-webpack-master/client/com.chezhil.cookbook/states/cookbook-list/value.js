'use strict';
let value = {
    cookbookClasses : [],
    id : 0,
    page : 1,
    title : '菜谱列表',
    cookbookItems : [],
    maxItems : -1,
    updateTime : '',
    valOptions : [],
}

export default value;