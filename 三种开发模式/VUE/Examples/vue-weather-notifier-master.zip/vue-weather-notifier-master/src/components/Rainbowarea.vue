<template>
	<g id="rainbow">
    <g id="rainbowpaths">
      <ellipse cx="287" cy="250.5" rx="83.3" ry="49.1" fill="none" stroke="#d33227" stroke-miterlimit="10"/>
      <ellipse cx="287" cy="251.5" rx="95.3" ry="56.2" fill="none" stroke="#f5841f" stroke-miterlimit="10"/>
      <ellipse cx="286" cy="252.5" rx="106.3" ry="62.7" fill="none" stroke="#fcc62b" stroke-miterlimit="10"/>
      <ellipse cx="287.4" cy="253.6" rx="119.4" ry="70.4" fill="none" stroke="#a1b53a" stroke-miterlimit="10"/>
      <ellipse cx="288.7" cy="256.3" rx="135.4" ry="79.9" fill="none" stroke="#4478bc" stroke-miterlimit="10"/>
    </g>
    <ellipse id="blue" cx="288.2" cy="249.2" rx="73.9" ry="43.6" fill="#27aae1"/>
    <ellipse id="light" cx="325.9" cy="207" rx="71.3" ry="54.2" transform="matrix(0.91, -0.41, 0.41, 0.91, -56.02, 154.57)" opacity="0.76" fill="url(#radial-gradient-21)"/>
    <polygon id="beams" points="353.6 170.9 364.5 154.9 364 174.3 382.3 167.8 370.5 183.2 389.1 188.7 370.5 194.1 382.3 209.5 364 203 364.5 222.5 353.6 206.4 342.6 222.5 343.1 203 324.8 209.5 336.7 194.1 318 188.7 336.7 183.2 324.8 167.8 343.1 174.3 342.6 154.9 353.6 170.9" fill="#fcc62b" opacity="0.13"/>
    <g id="rainbowplat">
      <ellipse id="newgrad" cx="310" cy="233.2" rx="38.5" ry="86" transform="rotate(-82.8 333.58 235.12)" fill="url(#radial-gradient)"/>
      <g>
        <g>
          <path d="M327.5,222.7c-26-15-52.8-15-78.8,0h0c-13,7.5-19.5,15.1-19.5,22.8s6.5,15.2,19.5,22.8c26,15,52.8,15,78.8,0,13-7.5,19.5-15.1,19.5-22.8S340.5,230.2,327.5,222.7Z" transform="translate(0 4)" fill="#fee23b"/>
          <path d="M327.5,256.9c-26,15-52.8,15-78.8,0-13-7.5-19.5-15.1-19.5-22.8v11.4c0,7.6,6.5,15.2,19.5,22.8,26,15,52.8,15,78.8,0,13-7.5,19.5-15.1,19.5-22.8V234.1C347,241.7,340.5,249.4,327.5,256.9Z" transform="translate(0 4)" fill="url(#linear-gradient-22)"/>
          <path d="M327.5,211.4c-26-15-52.8-15-78.8,0h0c-13,7.5-19.5,15.1-19.5,22.8s6.5,15.2,19.5,22.8c26,15,52.8,15,78.8,0,13-7.5,19.5-15.1,19.5-22.8S340.5,218.9,327.5,211.4Z" transform="translate(0 4)" fill="#38394f"/>
        </g>
      </g>
      <g class="bow">
	      <path id="newrshadow" d="M293.3,229.7l5.6,19.7,38.8.6s15.3-10.3,6.3-24.3A64.3,64.3,0,0,0,322.7,209C309.7,203,293.3,229.7,293.3,229.7Z" transform="translate(0 4)" fill="url(#linear-gradient-25)"/>
	      <path id="ambient1" d="M303.5,221.7v22.7l40.4-4C344.7,231.8,341.1,231.1,303.5,221.7Z" transform="translate(0 4)" opacity="0.21" fill="url(#linear-gradient-26)"/>
	      <path id="ambient2" d="M326.5,211.4v22.8H347S347.7,220.3,326.5,211.4Z" transform="translate(0 4)" opacity="0.45" fill="url(#linear-gradient-27)"/>
	      <!--end shadow-->
        <path d="M307.5,244.4l-8.6,4.9c0-5.7,2-9.9,5.5-11.9l8.6-4.9C309.4,234.6,307.5,238.8,307.5,244.4Z" transform="translate(0 4)" fill="#4478bc"/>
        <polygon points="326.6 238.1 318 243.1 318 233 326.6 228.1 326.6 238.1" fill="#4478bc"/>
        <polygon points="326.6 228.1 318 233 318 223 326.6 218.1 326.6 228.1" fill="#89a13c"/>
        <polygon points="326.6 218.1 318 223 318 213 326.6 208 326.6 218.1" fill="#fcc62b"/>
        <polygon points="326.6 208 318 213 318 202.9 326.6 198 326.6 208" fill="#f5841f"/>
        <polygon points="326.6 198 318 202.9 318 192.9 326.6 187.9 326.6 198" fill="#d33227"/>
        <path d="M326.1,183.7c-17.2-9.9-32.7-10.8-43.9-4.3l-8.6,4.9c11.2-6.5,26.8-5.6,43.9,4.3l.5.3,8.6-4.9Z" transform="translate(0 4)" fill="url(#linear-gradient-23)"/>
        <g>
          <path d="M280.2,194.7c10.2-5.6,23.6-4.1,37.8,4.2v-10l-.5-.3c-17.2-9.9-32.7-10.8-43.9-4.3s-18.2,20.4-18.2,40.2l8.7,5c0-.2,0-.4,0-.6.1-16.2,5.7-28.2,15.6-34Z" transform="translate(0 4)" fill="#ee5823"/>
          <path d="M286.2,205.4c8.4-4.7,19.5-3.5,31.3,3.3l.5.3v-10c-14.2-8.4-27.7-9.9-37.8-4.2l-.4.2c-9.9,5.7-15.5,17.8-15.6,34,0,.2,0,.4,0,.6l8.7,5c0-.2,0-.4,0-.5.1-13.5,4.8-23.6,13.1-28.4Z" transform="translate(0 4)" fill="#f99c20"/>
          <path d="M292.3,216.1c6.8-3.8,15.7-2.8,25.2,2.7l.4.2h.1V209l-.5-.3c-11.8-6.8-22.9-8-31.3-3.3l-.3.2c-8.3,4.8-13,14.9-13.1,28.4,0,.2,0,.4,0,.5l8.7,5c0-.1,0-.3,0-.4.1-10.9,3.8-19,10.5-22.9Z" transform="translate(0 4)" fill="#fdd23c"/>
          <path d="M298.4,226.7c5.1-2.9,11.9-2.1,19.1,2l.3.2h.2V219h-.1l-.4-.2c-9.5-5.5-18.4-6.4-25.2-2.7l-.3.2c-6.7,3.9-10.4,12-10.5,22.9,0,.1,0,.3,0,.4l8.7,5c0-.1,0-.2,0-.3.1-8.3,2.9-14.4,8-17.4Z" transform="translate(0 4)" fill="#a1b53a"/>
          <path d="M317.8,228.9l-.3-.2c-7.2-4.2-14-4.9-19.1-2h-.2c-5.1,2.9-7.9,9.1-8,17.4,0,.1,0,.2,0,.3l8.7,5c0-.1,0-.1,0-.2,0-5.7,2-9.9,5.5-11.9h.1c3.5-1.9,8.1-1.5,13,1.4h.2l.3.2V229Z" transform="translate(0 4)" fill="#4b9ad4"/>
        </g>
      </g>
    </g>
    <g id="sun">
      <path d="M358.1,169.6c-3-2.3-6-2.9-8.3-2l-5.5,2.2c2.3-1,5.3-.4,8.3,2,6.1,4.7,10.2,14.7,9.2,22.3-.5,3.8-2.2,6.3-4.5,7.3l5.5-2.2c2.3-1,4-3.5,4.5-7.3C368.3,184.3,364.2,174.3,358.1,169.6Z" transform="translate(0 4)" fill="url(#linear-gradient-24)"/>
      <path d="M350.4,198.8a13,13,0,0,0,2.9,1.7l-2.8.5-2.2-4.1A18.5,18.5,0,0,0,350.4,198.8Zm4.7,2.3,3.1,2.3,1.4-3-.9.4A6.4,6.4,0,0,1,355.1,201.1Zm-14.3-29.8.6,4.5a9.9,9.9,0,0,1,2.2-5ZM361.6,182l-.6-4.5-3.1-2.3A28.3,28.3,0,0,1,361.6,182Zm-5.4-8.8-2.2-4.1-2.8.5a13,13,0,0,1,2.9,1.7A18.6,18.6,0,0,1,356.3,173.2Zm-6.9-4.2-3.1-2.3-1.4,3,.9-.4A6.3,6.3,0,0,1,349.4,169Zm14.3,29.8-.6-4.5a9.9,9.9,0,0,1-2.2,4.9Zm1.1-9.9-2.3-4.2a23.9,23.9,0,0,1,.9,7.2Z" transform="translate(0 4)" fill="url(#radial-gradient-22)"/>
      <g>
        <polygon points="361.2 206.2 358.2 207.4 359.6 204.3 362.6 203.1 361.2 206.2" fill="#faa51a"/>
        <polygon points="346.6 173.6 343.6 174.9 340.8 175.3 343.8 174.1 346.6 173.6" fill="#fdd800"/>
        <polygon points="366.6 201.5 363.7 202.8 363.1 198.3 366.1 197.1 366.6 201.5" fill="#fcb415"/>
        <polygon points="366.4 194.7 363.4 195.9 364.8 192.9 367.7 191.7 366.4 194.7" fill="#faa51a"/>
        <polygon points="367.7 191.7 364.8 192.9 362.5 188.7 365.5 187.5 367.7 191.7" fill="#fec40d"/>
        <polygon points="364.6 184.8 361.6 186 361.1 181.6 364 180.4 364.6 184.8" fill="#fcaf17"/>
        <polygon points="364 180.4 361.1 181.6 358 179.3 360.9 178.1 364 180.4" fill="#ffd10a"/>
        <polygon points="359.2 176 356.3 177.2 354 173.1 357 171.9 359.2 176" fill="#fdc010"/>
        <polygon points="357 171.9 354 173.1 351.2 173.6 354.2 172.3 357 171.9" fill="#fdd800"/>
        <polygon points="352.3 171.8 349.4 173 346.3 170.7 349.2 169.5 352.3 171.8" fill="#ffcc04"/>
      </g>
      <path d="M361.8,194.1c-.5,3.8-2.2,6.3-4.5,7.3s-5.3.4-8.3-2c-6.1-4.7-10.2-14.7-9.2-22.3.5-3.8,2.2-6.3,4.5-7.3s5.3-.4,8.3,2C358.8,176.5,362.9,186.5,361.8,194.1Z" transform="translate(0 4)" fill="url(#radial-gradient-23)"/>
      <path d="M353,184.7a3,3,0,0,1-5.3,2.2,10.9,10.9,0,0,1-3.8-9.1,3,3,0,0,1,5.3-2.2A10.9,10.9,0,0,1,353,184.7Z" transform="translate(0 4)" fill="#575858" style="mix-blend-mode: screen"/>
    </g>
  </g>
</template>


<script>
	export default {
		mounted () {
			let audio = new Audio('static/rainbow.mp3'),
					tl = new TimelineMax();

      audio.play();
      audio.volume = 0.2;
			tl.add("rainbow", "+=0.5");

			//rainbow
			tl.fromTo("#beams", 2.5, {
				scale: 0,
				opacity: 0,
				x: 36, 
				y: 34,
				rotation: 0
			}, {
				scale: 1,
				x: 36, 
				y: 34,
				opacity: 0.2,
				rotation: "-720",
				transformOrigin: "50% 50%",
				ease: Linear.easeNone
			}, "rainbow");

			tl.to("#beams", 4, {
				rotation: 360,
				repeat: 4,
				transformOrigin: "50% 50%",
				ease: Linear.easeNone
			}, "rainbow+=2.5");

			tl.fromTo(".bow, #sun", 1, {
				opacity: 0,
			}, {
				opacity: 1,
				ease: Sine.easeOut
			}, "rainbow");

			tl.fromTo("#light", 3, {
				opacity: 0,
			}, {
				opacity: 0.8,
				ease: Sine.easeOut
			}, "rainbow");

			tl.fromTo("#blue", 2, {
				opacity: 0,
				x: 36, 
				y: 21,
				scale: 0.5
			}, {
				opacity: 1,
				scale: 1,
				x: 36, 
				y: 21,
				transformOrigin: "50% 50%",
				ease: Sine.easeOut
			}, "rainbow");

			tl.staggerFromTo("#rainbowpaths ellipse", 1.5, {
				drawSVG: false
			}, {
				drawSVG: true,
				ease: Sine.easeIn
			}, 0.1, "rainbow");

			tl.fromTo(".r-piece1", 0.5, {
				y: 88
			}, {
				y: 58,
				ease: Sine.easeOut
			}, "rainbow");

		}
	}
</script>

<style scoped>
	#rainbow {
		-webkit-transform: translate(0px, 50px);;
		transform: translate(0px, 50px);;
	}
</style>