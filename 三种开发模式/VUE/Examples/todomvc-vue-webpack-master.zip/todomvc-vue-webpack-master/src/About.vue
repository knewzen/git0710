<template>
    <h3> About information </h3>
</template>

<script>
export default {

}
</script>