<template>
    <h2>
        {{ text }}</h2>
</template>

<script>
export default {
    props: ["text"]
}
</script>
