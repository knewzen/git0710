<template>
  <div class="users-select">
    <h1>Welcome to users!</h1>
    &larr; Select a user on sidebar
  </div>
</template>

<style>
  .users-select {
    flex-flow: column nowrap;
    justify-content: center;
    align-items: center;
  }
</style>
