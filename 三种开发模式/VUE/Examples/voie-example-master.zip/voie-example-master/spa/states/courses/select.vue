<template>
  <div class="courses-select">
    <h1>Welcome to courses!</h1>
    &larr; Select a course on sidebar
  </div>
</template>

<style>
  .courses-select {
    flex-flow: column nowrap;
    justify-content: center;
    align-items: center;
  }
</style>
