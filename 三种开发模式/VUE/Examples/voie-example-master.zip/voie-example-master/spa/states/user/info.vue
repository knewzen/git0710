<template>
  <div class="user-info">
    <p>
      Welcome to {{ user.name }}!
    </p>
  </div>
</template>
