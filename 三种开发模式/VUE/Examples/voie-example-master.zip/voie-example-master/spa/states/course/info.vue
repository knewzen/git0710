<template>
  <div class="course-info">
    <p>
      Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto asperiores cupiditate et explicabo id laborum mollitia recusandae rerum tempore vitae?
    </p>
  </div>
</template>
