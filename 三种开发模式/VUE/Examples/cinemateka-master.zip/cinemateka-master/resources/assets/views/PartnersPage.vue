<template>
  <div>
    <div class="mdl-grid partners-page">
      <div class="mdl-cell mdl-cell--12-col">
        <h1>Партнеры</h1>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="spb">
          <a href="http://gov.spb.ru/gov/admin/" target="_blank">
            <img src="/images/partners/img-partners-spb.png" alt="Правительство Санкт-Петербурга" title="Правительство Санкт-Петербурга">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="godkino">
          <a href="http://god-kino2016.ru/" target="_blank">
            <img src="/images/partners/img-partners-godkino.png" alt="Год российского кино" title="Год российского кино">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="vforum">
          <a href="https://culturalforum.ru/ru" target="_blank">
            <img src="/images/partners/img-partners-vforum.png" alt="Культурный форум" title="Культурный форум">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="filmfound">
          <a href="http://gosfilmofond.ru/" target="_blank">
            <img src="/images/partners/img-partners-filmfound.png" alt="Госфильмофонд России" title="Госфильмофонд России">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="lenfilm">
          <a href="http://www.lenfilm.ru/" target="_blank">
            <img src="/images/partners/img-partners-lenfilm.png" alt="Ленфильм" title="Ленфильм">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="mosfilm">
          <a href="http://mosfilm.ru/main.php" target="_blank">
            <img src="/images/partners/img-partners-mosfilm.png" alt="Мосфильм" title="Мосфильм">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="rodina">
          <a href="http://rodinakino.ru/" target="_blank">
            <img src="/images/partners/img-partners-rodina.png" alt="Кинотеатр Родина" title="Кинотеатр Родина">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="avrora">
          <a href="http://www.avrora.spb.ru/" target="_blank">
            <img src="/images/partners/img-partners-avrora.png" alt="Кинотеатр Аврора" title="Кинотеатр Аврора">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="newstage">
          <a href="http://thenewstage.ru" target="_blank">
            <img src="/images/partners/img-partners-newstage.png" alt="Новая сцена Александринского театра" title="Новая сцена Александринского театра">
          </a>
        </div>
      </div>
      <!-- <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="seance">
          <a href="http://seance.ru/" target="_blank">
            <img src="/images/partners/img-partners-seance.png" alt="Сеанс" title="Сеанс">
          </a>
        </div>
      </div> -->
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="porydokslov">
          <a href="http://wordorder.ru/" target="_blank">
            <img src="/images/partners/img-partners-porydokslov.png" alt="Порядок слов" title="Порядок слов">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="kinotv">
          <a href="http://kinochannel.ru/" target="_blank">
            <img src="/images/partners/img-partners-kinotv.png" alt="Кино ТВ" title="Кино ТВ">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="roadradio">
          <a href="https://dorognoe.ru/?region=piter" target="_blank">
            <img src="/images/partners/img-partners-roadradio.png" alt="Дорожное радио" title="Дорожное радио">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="tvspb">
          <a href="http://topspb.tv/" target="_blank">
            <img src="/images/partners/img-partners-tvspb.png" alt="ТВ Санкт-Петербург" title="ТВ Санкт-Петербург">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="kinoafisha">
          <a href="http://www.kinoafisha.spb.ru/" target="_blank">
            <img src="/images/partners/img-partners-kinoafisha.png" alt="Киноафиша" title="Киноафиша">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="kultkino">
          <a href="http://cultofcinema.com/" target="_blank">
            <img src="/images/partners/img-partners-kultkino.png" alt="Культкино" title="Культкино">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="go2go">
          <a href="http://www.2do2go.ru/spb" target="_blank">
            <img src="/images/partners/img-partners-2go2go.png" alt="2do2go" title="2do2go">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="kudago">
          <a href="http://kudago.com/spb/" target="_blank">
            <img src="/images/partners/img-partners-kudago.png" alt="Kudago" title="Kudago">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="bumaga">
          <a href="http://paperpaper.ru" target="_blank">
            <img src="/images/partners/img-partners-bumaga.png" alt="Бумага" title="Бумага">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="thevillage">
          <a href="http://www.the-village.ru/" target="_blank">
            <img src="/images/partners/img-partners-thevillage.png" alt="Вилладж" title="Вилладж">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="newsdale">
          <a href="http://www.newsdale.ru/" target="_blank">
            <img src="/images/partners/img-partners-newsdale.png" alt="Newsdale" title="Newsdale">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="bukvoed">
          <a href="http://www.bookvoed.ru/" target="_blank">
            <img src="/images/partners/img-partners-bukvoed.png" alt="Буквоед" title="Буквоед">
          </a>
        </div>
      </div>            
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="morecoffe">
          <a href="https://new.vk.com/morecoffee" target="_blank">
            <img src="/images/partners/img-partners-morecoffe.png" alt="Больше кофе" title="Больше кофе">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="chronicles">
          <a href="https://new.vk.com/xronikibar" target="_blank">
            <img src="/images/partners/img-partners-chronicles.png" alt="Бар Хроники" title="Бар Хроники">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="afisha">
          <a href="http://www.afisha.ru" target="_blank">
            <img src="/images/partners/img-partners-afisha.png" alt="Афиша" title="Афиша">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="spb2">
          <a href="http://peterburg2.ru" target="_blank">
            <img src="/images/partners/img-partners-spb2.png" alt="Петербург2" title="Петербург2">
          </a>
        </div>
      </div>
      <div class="partner-item mdl-cell mdl-cell--2-col mdl-cell--3-col-desktop">
        <div class="kinolenfilm">
          <a href="#" target="_blank">
            <img src="/images/partners/img-partners-kinolenfilm.png" alt="Кинотеатр Ленфильм" title="Кинотеатр Ленфильм">
          </a>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {

  head: {
    title() {
      return {
        inner: 'О проектe',
        separator: '|',
        complement: this.$root.meta.app
      }
    },
    meta() {
      let description = '',
        title = 'О проектe - ' + this.$root.meta.app,
        image = ''
      return {
        name: {
          'application-name': this.$root.meta.app,
          description: description,
          'twitter:title': title,
          'twitter:description': description,
          'twitter:image': image
        }, //' comment to fix sublime highlighting
        itemprop: {
          name: title,
          description: description,
          image: image
        },
        property: {
          'fb:app_id': this.$root.meta.fbAppId,
          'og:url': window.location.href,
          'og:title': title,
          'og:description': description,
          'og:image': image
        } //' comment to fix sublime highlighting
      }
    }
  }

}
</script>
<style lang="sass" scoped>
.partners-page {
  margin-bottom: 100px;
}
.partner-item {
  height: 250px;
  line-height: 250px;
  text-align: center;
  &> div {
    width: 260px;
    height: 252px;
    img:hover {
      opacity: 0;
      transition: opacity .3s linear;
    }
  }
}
.godkino {
  background-image: url('/images/partners/img-partners-godkino-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.vforum {
  background-image: url('/images/partners/img-partners-vforum-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.kinotv {
  background-image: url('/images/partners/img-partners-kinotv-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.newstage {
  background-image: url('/images/partners/img-partners-newstage-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.seance {
  background-image: url('/images/partners/img-partners-seance-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.spb {
  background-image: url('/images/partners/img-partners-spb-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.filmfound {
  background-image: url('/images/partners/img-partners-filmfound-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.kultkino {
  background-image: url('/images/partners/img-partners-kultkino-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.kinoafisha {
  background-image: url('/images/partners/img-partners-kinoafisha-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.avrora {
  background-image: url('/images/partners/img-partners-avrora-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.kinolenfilm {
  background-image: url('/images/partners/img-partners-kinolenfilm-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.lenfilm {
  background-image: url('/images/partners/img-partners-lenfilm-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.rodina {
  background-image: url('/images/partners/img-partners-rodina-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.roadradio {
  background-image: url('/images/partners/img-partners-roadradio-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.bukvoed {
  background-image: url('/images/partners/img-partners-bukvoed-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.porydokslov {
  background-image: url('/images/partners/img-partners-porydokslov-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.bumaga {
  background-image: url('/images/partners/img-partners-bumaga-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.chronicles {
  background-image: url('/images/partners/img-partners-chronicles-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.morecoffe {
  background-image: url('/images/partners/img-partners-morecoffe-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.thevillage {
  background-image: url('/images/partners/img-partners-thevillage-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.newsdale {
  background-image: url('/images/partners/img-partners-newsdale-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.kudago {
  background-image: url('/images/partners/img-partners-kudago-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.go2go {
  background-image: url('/images/partners/img-partners-2go2go-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.tvspb {
  background-image: url('/images/partners/img-partners-tvspb-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.spb2 {
  background-image: url('/images/partners/img-partners-spb2-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.mosfilm {
  background-image: url('/images/partners/img-partners-mosfilm-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}
.afisha {
  background-image: url('/images/partners/img-partners-afisha-hover.png');
  background-position: 50% 50%;
  background-repeat: no-repeat;
}

</style>
