<!-- \seance-logo -->
<div class="col s2 seance-logo">
  <div class="wrap">
    <a href="http://seance.ru" class="brand-logo right">
      <img src="{{ config('app.logo.s-img') }}" alt="{{ config('app.logo.alt') }}">
    </a>
  </div>
</div>
<!-- /seance-logo -->
