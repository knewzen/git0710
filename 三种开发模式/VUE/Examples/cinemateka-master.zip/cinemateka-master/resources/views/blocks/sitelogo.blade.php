<!-- \site-logo -->
<div class="col s2 site-logo">
  <div class="wrap">
    <a v-link="{ path: '/' }" class="brand-logo left">
      <img src="{{ config('app.logo.img') }}" alt="{{ config('app.logo.alt') }}">
    </a>
  </div>
</div>
<!-- /site-logo -->
