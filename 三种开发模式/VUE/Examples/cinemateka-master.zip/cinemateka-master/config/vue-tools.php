<?php

return [

	/* this contains useful defaults that are used by the vue tools framework */

	'default_date_format' => 'h:i',

];