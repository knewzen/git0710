<?php

return [
	'table' => 'image_files'	// Table name your want to use.
];
