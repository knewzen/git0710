<?php

return [

	// Language files to NOT show in the LangFileManager
	//
	'language_ignore' => ['admin', 'pagination', 'reminders', 'validation', 'log', 'crud'],

];


