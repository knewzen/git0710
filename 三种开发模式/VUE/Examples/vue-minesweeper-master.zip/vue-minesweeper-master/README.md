# vue-minesweeper
deadly simple minesweeper with vuejs

all code in index.html (about 200+ loc)


[Live Demo](https://codepen.io/rhapsodyn/pen/wqPXJG)
