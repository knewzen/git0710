var Vue = require('vue');

import messages from './messages.vue';

export default Vue.component('messages', messages);