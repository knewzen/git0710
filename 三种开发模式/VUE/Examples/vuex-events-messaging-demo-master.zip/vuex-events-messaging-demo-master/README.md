# vuex-events-messaging-demo

> A [Metric Loop](https://metricloop.com) Demo

This demo will show you how to get up and running with Vuex. For a detailed walkthrough on how to use it, check out our [blog post](https://metricloop.com/blog/how-to-use-vuex-to-build-a-feature). 

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```
