import state from './basket.state'
import actions from './basket.actions'
import mutations from './basket.mutations'

export default {
  state,
  actions,
  mutations
}
