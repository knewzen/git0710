const state = {
  basket: {
    products: []
  }
}

export default state
