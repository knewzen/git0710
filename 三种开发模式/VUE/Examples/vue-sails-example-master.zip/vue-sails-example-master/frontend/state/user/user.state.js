const state = {
  user: {
    id: '',
    name: '',
    password: ''
  }
}

export default state
