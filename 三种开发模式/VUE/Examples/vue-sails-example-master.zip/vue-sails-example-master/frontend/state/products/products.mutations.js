const mutations = {
  /**
   * @param state
   * @param products
   */
  SET_PRODUCTS(state, products) {
    state.products = products
  }
}

export default mutations
