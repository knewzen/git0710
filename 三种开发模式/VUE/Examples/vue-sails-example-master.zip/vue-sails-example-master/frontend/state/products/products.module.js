import state from './products.state'
import actions from './products.actions'
import mutations from './products.mutations'

export default {
  state,
  actions,
  mutations
}
