const state = {
  products: {}
}

export default state
