import state from './product.state'
import mutations from './product.mutations'
import actions from './product.actions'

export default {
  state,
  mutations,
  actions
}
