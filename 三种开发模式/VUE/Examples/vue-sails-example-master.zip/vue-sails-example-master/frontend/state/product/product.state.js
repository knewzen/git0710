const state = {
  product: {
    title: '',
    description: '',
    price: 0,
    meta: {
      isEditProductVisible: false
    }
  }
}

export default state
