/**
 * Style Imports
 */
import '!style!css!less!./AdminLTE.less'
import '!style!css!less!./vue-animate.less'  // Dogfooding in action

/**
 * Script Imports
 */
import 'admin-lte/plugins/slimScroll/jquery.slimscroll.min.js'
import 'admin-lte/dist/js/app.min.js'
