module.exports =  {
	addTask: 'ADD_TASK',
	deleteTask: 'DELETE_TASK',
	toggleTask: 'TOGGLE_TASK',
	editTask: 'EDIT_TASK'
}