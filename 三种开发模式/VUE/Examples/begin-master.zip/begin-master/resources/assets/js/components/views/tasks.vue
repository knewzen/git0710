<template>
	<nav-component></nav-component>
	<div class="container">
		<div class="row">
			<div class="col-sm-12"><router-view></router-view></div>
		</div>
	</div>
	<footer-component></footer-component>
</template>



