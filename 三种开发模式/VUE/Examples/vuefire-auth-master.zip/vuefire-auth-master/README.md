# vuefire-auth

> A Vue.js with vuefire auth project

![alt tag](http://i.imgur.com/QFVjAny.png)
## Config
> firebase auth enabled
![alt tag](http://images2015.cnblogs.com/blog/364241/201610/364241-20161031025159315-140732564.png)

At -> src/components/Hello.vue     [firebase console](https://console.firebase.google.com/)
``` bash
let config = {
//firebase console
}
```

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```
## Project New🔥!!!
[Vue Firebase Authentication with Vuex and support Progressive Web Apps](https://github.com/aofdev/vue-firebase-auth-vuex)
