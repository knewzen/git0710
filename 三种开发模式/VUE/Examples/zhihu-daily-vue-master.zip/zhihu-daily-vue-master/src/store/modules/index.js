import hello from './hello'
import bootimage from './bootimage'
import news from './news'
import theme from './theme'

export {
  hello,
  bootimage,
  news,
  theme
}
