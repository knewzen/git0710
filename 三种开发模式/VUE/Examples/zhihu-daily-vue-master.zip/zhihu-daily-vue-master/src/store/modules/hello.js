const state = {
  text: 'Hello world'
}

export default {
  state
}
