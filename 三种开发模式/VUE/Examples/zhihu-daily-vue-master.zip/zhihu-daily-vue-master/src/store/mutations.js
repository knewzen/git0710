export const GETBOOTIMAGE = 'getbootimage'
export const UPDATENEWS = 'updatenews'
export const UPDATETHEMES = 'updatethemes'
