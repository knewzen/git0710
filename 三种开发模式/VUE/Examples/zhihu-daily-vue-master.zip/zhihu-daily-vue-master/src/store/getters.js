export const bootimage = state => state.bootimage
export const news = state => state.news.news
export const themes = state => state.theme.data
