# VuejsSSRSample

A sample about Vue.js 2 server-side rendering with ASP.NET Core 2.0.
