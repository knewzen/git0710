/* 数据库配置文件 */

module.exports = {
  host: 'localhost',
  port: 27017,
  dbname: 'test',
  url: 'mongodb://localhost:27017/test',
};
