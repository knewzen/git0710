import Avatar from './Avatar.vue';

export default Avatar;
