<template>
  <div class="avatar">
    {{shortName}}
  </div>
</template>

<script>

  import Avatar from './Avatar.js';

  export default Avatar;

</script>

<style lang="less" scoped>
  @import './Avatar.less';
</style>
