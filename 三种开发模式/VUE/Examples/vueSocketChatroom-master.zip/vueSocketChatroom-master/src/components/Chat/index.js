import Chat from './Chat.vue';

export default Chat;
