import GroupChat from './GroupChat.vue';

export default GroupChat;
