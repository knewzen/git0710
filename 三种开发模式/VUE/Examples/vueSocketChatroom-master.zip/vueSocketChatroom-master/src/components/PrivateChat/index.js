import PrivateChat from './PrivateChat.vue';

export default PrivateChat;
