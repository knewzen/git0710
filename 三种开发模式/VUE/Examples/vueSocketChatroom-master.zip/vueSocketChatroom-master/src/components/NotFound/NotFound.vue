<template>
  <div>
  404
  </div>
</template>

<script>

import NotFound from './NotFound.js';

export default NotFound;

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>

@import './NotFound.less';

</style>
