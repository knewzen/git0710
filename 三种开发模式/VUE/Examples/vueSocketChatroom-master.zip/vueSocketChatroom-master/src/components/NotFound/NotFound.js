export default {
  name: 'NotFound',
  data() {
    return {
    };
  },
  methods: {
  },
};
