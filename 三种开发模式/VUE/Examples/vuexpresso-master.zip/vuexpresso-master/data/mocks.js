const mocks = {};

export default mocks;
