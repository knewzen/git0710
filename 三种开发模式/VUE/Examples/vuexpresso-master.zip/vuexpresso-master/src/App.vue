<template lang="jade">
  .app
    router-view
</template>

<script>

export default {
  name: 'app',
};
</script>
