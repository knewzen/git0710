import preview from 'vue-play/preview';
import '.';

preview();
