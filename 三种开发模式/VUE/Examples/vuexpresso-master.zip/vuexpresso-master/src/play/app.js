import app from 'vue-play/app';

app();
