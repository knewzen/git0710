export default {
  AWS_LAMBDA_GETSIGNEDURL_ENDPOINT: '/your-lambda-endpoint-goes-here'
}
