export function getUserView (state) {
  return state.user.user
}
export function getFtpsFilters (state) {
  return state.ftpsfilter.ftpsselect
}
export function getFtpSelect (state) {
  return state.ftpsfilter.ftpselect
}
export function getModeFilter (state) {
  return state.ftpsfilter.modefilter
}
export function getFtpsList (state) {
  return state.ftpsfilter.ftpslist
}

