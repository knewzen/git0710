<template>
  <div>
  	<router-view></router-view>
  </div>     
   	  
</template>

<script>
import store from '../vuex/store'
export default {
  store,
  methods: {
  }
}
</script>

