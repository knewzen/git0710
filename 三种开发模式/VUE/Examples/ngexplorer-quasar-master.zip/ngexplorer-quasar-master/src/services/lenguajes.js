export default {
  lenguajes: [
    {
      label: 'Español',
      value: 'es'
    },
    {
      label: 'Ingles',
      value: 'en'
    },
    {
      label: 'Ruso',
      value: 'ru'
    }
  ]
}
