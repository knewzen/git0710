<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Vue - Laravel - Example</title>

  <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
</head>
<body>
  <div id="app"></div>

  <script src="{{ asset('js/main.js') }}"></script>
</body>
</html>
