<p align="center">
  <br>
  <b>创造不息，交付不止</b>
  <br>
  <a href="https://www.yousails.com">
    <img src="https://yousails.com/banners/brand.png" width=350>
  </a>
</p>

## Vue - Laravel - Example

Vue - Laravel - Example is a simple example to set `Vue 2.0` with `Laravel 5.1`.

## Install

1. Clone the project to local

  ```
  git clone https://github.com/jcc/vue-laravel-example.git
  cd vue-laravel-example
  ```

1. Install the dependencies

  ```
  composer install
  npm install
  ```

1. Compiling Assets

  ```
  gulp
  ```

1. Visit the site: [http://vue-laravel.app]()

### License

The Vue - Laravel - Example is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)
