<template>
  <div id="app">
      <router-view class="view"></router-view>
  </div>
</template>
<style lang="scss">
@import '../static/normalize/normalize.css';
@import './assets/styles/blog.scss';
</style>