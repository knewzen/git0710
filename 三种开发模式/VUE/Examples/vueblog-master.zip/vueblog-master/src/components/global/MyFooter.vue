<template>
  <footer class="container footer">
    <div class="copy">
      <div class="licensed">Licensed under <a href="https://choosealicense.com/licenses/gpl-3.0/">GPL-3.0</a> license.</div>
      <div class="powered">Powered by <a href="https://github.com/wmui/vueblog">VueBlog</a>. Theme by <a href="https://github.com/wmui">wmui</a></div>
    </div>
  </footer>
</template>