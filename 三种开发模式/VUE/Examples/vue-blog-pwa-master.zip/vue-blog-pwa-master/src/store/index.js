var state = {
  'username': undefined,
  'last_login': undefined
}

export default state
