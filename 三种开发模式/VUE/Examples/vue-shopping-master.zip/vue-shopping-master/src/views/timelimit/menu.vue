<!--<style>





  .MCUBE_MOD_ID_8383 .nav-bottom .bottom-text {
    display: block;
    color: #999;
    font-size: .25rem;
  }
  .MCUBE_MOD_ID_8383 .nav-bottom .bottom-text {
    color: #999;
  }
  .MCUBE_MOD_ID_8383 .nav-bottom .active .bottom-text {
    color: #f13e3a;
  }
  .MCUBE_MOD_ID_8383 .nav-bottom .bottom-icon {
    margin: .04rem auto;
    margin-top: .128rem;
    display: block;
    background-size: 100% auto;
    overflow: hidden;
    text-indent: -9999px;
    text-align: left;
    width: .41rem;
    height: .41rem;
  }
  .MCUBE_MOD_ID_8383 .nav-bottom .bottom-icon {
    background-image: url("");
  }
  .MCUBE_MOD_ID_8383 .nav-bottom a {
    box-sizing: border-box;
    display: block;
    text-align: center;
    padding-bottom: .1rem;
    color: #666;
    -webkit-box-flex: 1;
    -moz-box-flex: 1;
    width: 0;
    overflow: hidden;
  }
  .MCUBE_MOD_ID_8383 .nav-bottom {
    width: 100%;
    max-width: 750px;
    margin: 0 auto;
    position: fixed;
    z-index: 250;
    background: #fafafa;
    bottom: 0;
    height: 1rem;
    overflow: hidden;
    border-top: 1px solid #e5e5e5;
    display: -webkit-box;
    -webkit-box-orient: horizontal;
  }
  .MCUBE_MOD_ID_8383 .nav-bottom {
    background-color: #fafafa;
  }
  .MCUBE_MOD_ID_8383 {
    height: 1rem;
  }
</style>-->
<template>
  <div class="module_row module_row_18276 MOD_ID_8383">
    <div class="mod_row MCUBE_MOD_ID_8383">
      <div class="nav-bottom">
        <a data-href="http://qiang.mogujie.com/fastbuy/indexh5" href="javascript:void(0);" class="nav-bottom-item active">
          <i class="bottom-icon icon-fastbuy" style="background-image: url(&quot;http://s17.mogucdn.com/p1/151022/upload_ie4toojxgm2wknjwgqzdambqgqyde_41x41.png&quot;);" bg_img_act="http://s17.mogucdn.com/p1/151022/upload_ie4toojxgm2wknjwgqzdambqgqyde_41x41.png"></i>
          <span class="bottom-text" style="color:;">快抢</span>
        </a>
        <a data-href="http://act.mogujie.com/fastbuy/lastcrazy" href="javascript:void(0);" class="nav-bottom-item">
          <i class="bottom-icon icon-fastbuy" style="background-image:url(http://s17.mogucdn.com/p1/151022/upload_ie4ginbvg44winjwgqzdambqgiyde_41x41.png);" bg_img_act="http://s18.mogucdn.com/p1/151022/upload_ie4don3dga3gknjwgqzdambqgiyde_41x41.png"></i>
          <span class="bottom-text" style="color:;">最后疯抢</span>
        </a>
        <a data-href="http://act.mogujie.com/fastbuy/onecent" href="javascript:void(0);" class="nav-bottom-item">
          <i class="bottom-icon icon-fastbuy" style="background-image:url(http://s17.mogucdn.com/p1/151022/upload_ie4wgzbygq2gknjwgqzdambqgqyde_39x41.png);" bg_img_act="http://s17.mogucdn.com/p1/151022/upload_ie3tooleg44winjwgqzdambqgayde_39x41.png"></i>
          <span class="bottom-text" style="color:;">一分钱抽奖</span>
        </a>
      </div>
    </div>
  </div>
</template>
