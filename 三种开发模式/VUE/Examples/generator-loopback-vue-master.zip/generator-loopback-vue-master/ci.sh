  npm i
  npm run build:js
 
  
