'use strict';

module.exports = function(Appversion) {

};
