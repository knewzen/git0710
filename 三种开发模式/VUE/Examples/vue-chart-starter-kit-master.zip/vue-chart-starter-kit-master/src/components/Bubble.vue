<template lang="html">
  <div>
    <bubble-chart></bubble-chart>
  </div>
</template>

<script>
import BubbleChart from '../charts/BubbleChart.js'

export default {
  components: {
    'bubble-chart': BubbleChart
  }
}
</script>

<style lang="css">
</style>
