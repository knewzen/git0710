defmodule BasicApp.LayoutView do
  use BasicApp.Web, :view
end
