defmodule BasicApp.PageView do
  use BasicApp.Web, :view
end
