defmodule BasicApp.Repo do
  use Ecto.Repo, otp_app: :basic_app
end
