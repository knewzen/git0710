defmodule BasicApp.PageViewTest do
  use BasicApp.ConnCase, async: true
end
