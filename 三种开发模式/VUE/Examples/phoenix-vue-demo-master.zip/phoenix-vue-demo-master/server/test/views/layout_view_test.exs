defmodule BasicApp.LayoutViewTest do
  use BasicApp.ConnCase, async: true
end
