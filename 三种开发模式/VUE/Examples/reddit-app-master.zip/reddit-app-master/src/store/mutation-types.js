//Home module
export const GET_LIST_DATA = 'GET_LIST_DATA'
export const GET_MORE_LIST_DATA = 'GET_MORE_LIST_DATA'
export const CATEGORY_CHANGE = 'CATEGORY_CHANGE'
export const SORTWAY_CHANGE = 'SORTWAY_CHANGE'
export const CLEAR_LIST = 'CLEAR_LIST'

//common
export const COM_IS_LOADING = 'COM_IS_LOADING'

//error
export const SHOW_ERROR_TOAST = 'SHOW_ERROR_TOAST'