var Sample;
(function (Sample) {
    var Modal;
    (function (Modal) {
        new Vue({
            el: '#sample',
            data: {
                showModal: false
            },
        });
    })(Modal = Sample.Modal || (Sample.Modal = {}));
})(Sample || (Sample = {}));
