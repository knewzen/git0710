﻿module Sample.Modal {

    new Vue({
        el: '#sample',
        data: {
            showModal: false
        },
    });
}
