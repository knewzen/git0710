var Sample;
(function (Sample) {
    var KO1;
    (function (KO1) {
        new Vue({
            el: '#sample',
            data: null,
        });
    })(KO1 = Sample.KO1 || (Sample.KO1 = {}));
})(Sample || (Sample = {}));
