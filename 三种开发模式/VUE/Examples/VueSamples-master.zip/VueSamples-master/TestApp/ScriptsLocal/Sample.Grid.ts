﻿module Sample.KO1 {

    new Vue({
        el: '#sample',
        data: null,
    });
}
