
VisualStudio 2015 project show casing VueJS, TypeScript, Bootstrap

- VueJS: http://vuejs.org
- Bootstrap: http://getbootstrap.com/
- TypeScript: http://www.typescriptlang.org/

(also requires "Web Compiler" VS Extension to turn .less file into .css)

Mostly a collection of simple but progressively complex samples.
It's an empty MVC project with WebAPI setup in the eventuality of doing some JSON experiment with Vue.
As well as some advanced sample and reusable control I need for my own projects.


TODO:
	+ Paged Sorted grid
	+ add some JSON loader... (with wait animation)


port to Vue 1.0 rc1
https://github.com/vuejs/vue/releases/tag/1.0.0-rc.1
http://rc.vuejs.org/guide/installation.html
CDNJS: http://cdnjs.cloudflare.com/ajax/libs/vue/1.0.0-rc.1/vue.min.js
