import { Vue } from './vue';
import router from './router';

export { Vue, router };
