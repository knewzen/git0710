'use strict'
import Application from './application'

global.application = new Application()
global.application.run()
