/**
 * Created by OXOYO on 2017/5/9.
 */
import Flowchart from './Flowchart.vue'

export default Flowchart
