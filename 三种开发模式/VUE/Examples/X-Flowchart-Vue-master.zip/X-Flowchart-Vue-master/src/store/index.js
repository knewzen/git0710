/**
 * Created by OXOYO on 2017/4/5.
 * store.js
 */

import state from './state'
import * as actions from './actions'
import mutations from './mutations'

export default {
  state,
  actions,
  mutations
}
