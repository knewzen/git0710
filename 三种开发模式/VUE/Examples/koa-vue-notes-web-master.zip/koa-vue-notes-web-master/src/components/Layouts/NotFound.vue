<template>
    <div class="panel">
        <h1>Not Found</h1>
        <p>Hmm, we couldn't quite find what you were looking for.</p>
        <router-link to="/" class="btn btn-primary">Go Home</router-link>
    </div>
</template>

<script>
    export default {
        name: 'notFound',
        mounted () {
        }
    }
</script>

<style lang="sass" scoped>
</style>
