<template>
    <section class="footer-main">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <p><a href="https://github.com/johndatserakis">Koa-Vue-Notes</a> is a SPA using Koa (2.3) as the <a href="https://github.com/johndatserakis/koa-vue-notes-api">backend</a> and Vue (2.3) as the <a href="https://github.com/johndatserakis/koa-vue-notes-api">frontend</a>.</p>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
    export default {
        name: 'footer-main',
        methods: {
        },
        computed: {
        }
    }
</script>

<style lang="sass" scoped>
</style>
