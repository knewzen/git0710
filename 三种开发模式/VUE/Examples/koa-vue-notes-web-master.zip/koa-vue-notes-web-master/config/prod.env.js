module.exports = {
  NODE_ENV: '"production"',
  API_URL: '"https://koa-vue-notes-api.innermonkdesign.com"',
  APP_URL: '"https://koa-vue-notes-web.innermonkdesign.com"'
}
