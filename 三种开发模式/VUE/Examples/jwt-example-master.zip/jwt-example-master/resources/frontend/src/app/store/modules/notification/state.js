export const state = {
  all: [],
};
