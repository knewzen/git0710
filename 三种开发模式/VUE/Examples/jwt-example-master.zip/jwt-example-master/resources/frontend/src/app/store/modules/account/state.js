export const state = {
  id: null,
  email: null,
  name: null,
};
