<template src="./alert.html"></template>
<script src="./alert.js" lang="babel"></script>
