import all from './all';
import destroy from './destroy';
import store from './store';

export default {
  all,
  destroy,
  store,
};
