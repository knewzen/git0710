<template src="./pagination.html"></template>
<script src="./pagination.js" lang="babel"></script>
