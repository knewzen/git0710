/* ============
 * Minimal Layout
 * ============
 */

export default {};
