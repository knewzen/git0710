<template src="./minimal.html"></template>
<script src="./minimal.js" lang="babel"></script>
