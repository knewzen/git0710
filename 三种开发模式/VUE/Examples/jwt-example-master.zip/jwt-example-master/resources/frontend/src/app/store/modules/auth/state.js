export const state = {
  authenticated: false,
};
