<template src="./index.html"></template>
<script src="./index.js" lang="babel"></script>
