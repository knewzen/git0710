import find from './find';

export default {
  find,
};
