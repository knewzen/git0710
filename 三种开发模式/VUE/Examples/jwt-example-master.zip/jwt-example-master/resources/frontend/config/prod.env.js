module.exports = {
  NODE_ENV: '"production"',
  API_LOCATION: '"api/v1"',
}
