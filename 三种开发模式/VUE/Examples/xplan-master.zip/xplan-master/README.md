## A rotating earth H5 page with Vue and threejs

This is a vue clone of [the original H5 site](https://wa.qq.com/xplan/earth/index.html)

![](https://jackgit.github.io/xplan/illustration_01.jpg)


## How to play

1. open [it](http://xplan.jackyang.me) with chrome mobile debug mode
2. touch and rotate the earth
3. long press the bottom button
4. you will then see the magic
