module.exports = {
  id: 'a',
  template: require('./template.html'),
  data: {
    msg: 'I am component A'
  }
}