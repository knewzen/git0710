module.exports = {
  id: 'b',
  template: require('./template.html'),
  data: {
    msg: 'I am component B!'
  }
}