# vue-table-pagination
一款用vue.js制作的带有分页导航的表格，同时使用boostrap样式。小巧，清新，易用
