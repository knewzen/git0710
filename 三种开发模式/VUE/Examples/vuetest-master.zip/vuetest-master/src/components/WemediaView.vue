<template>
  <div class="appblanker-container">
    <div class="appblanker">
      <h3>自媒体用户请用手机扫二维码进入</h3>
      <br><br>
      <img src="/static/pic/214.pic.jpg">
      <br><br><br>
      <a href="http://www.chudianyun.com/download/chuxiang_v1.apk">android版客户端</a>&nbsp;|&nbsp;
      <a v-link="{name:'index'}">返回首页</a>
    </div>
  </div>
</template>
