<template>
  <div class="container-fluid">
    <center class="qrcode"><img src="/static/pic/indexqrcode.gif"><br>关注公众号</center>
    <h5>联系我们</h5>
    <p>客服电话：010-84417406</p>
    <p>版权所有©触点（海南）传媒有限公司   京ICP备16021137号</p>
  </div>
</template>
