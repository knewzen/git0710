# vuetest 

this project is for  mandarin(中文) only

> VUE TEST BY Sjerrys

file uploader, user auth, text editor, bootstrap stuff. 

can be use with any kind of backend server: php, nodejs, java...

npm install [vue-strap](https://github.com/yuche/vue-strap) is not working in vue-cli created project

so I just put the vue-strap source-code in my src dir. 

it is also easier for someone who want to make a vue-strap localize copy.


## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# run unit tests
npm run unit

# run e2e tests
npm run e2e

# run all tests
npm test
```

For detailed explanation on how things work, checkout the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
