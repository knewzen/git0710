# vue2-realtimedatabaseCRUD with firebase

> A vue2-CRUD with firebase project

![alt tag](http://i.imgur.com/nnEULeT.png)

## Config
At -> src/App.vue     [firebase console](https://console.firebase.google.com/)
``` bash
let config = {
    //firebase console
}
```
## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build
```

